import nanovm.smbot.drivers.*;

class TypeDoubleTest {

  // set status led state and wait a second
  public static void main(String[] args) {
	double l;
	
	l = 1.2;
	System.out.println("d = " + l );
	l = 23.45;
	System.out.println("d = " + l );
	l = 234.456;
	System.out.println("d = " + l );
	l = 2345.6789;
	System.out.println("d = " + l );	
  }
}

     
