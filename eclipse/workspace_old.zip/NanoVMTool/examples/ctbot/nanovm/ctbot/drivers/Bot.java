package nanovm.ctbot.drivers;

public class Bot
{
  public static native boolean getError();
  public static native void setExtension1Enabled(boolean enable);
  public static native boolean getExtension1Enabled();
  public static native void setExtension2Enabled(boolean enable);
  public static native boolean getExtension2Enabled();
}

