

class JavaTest_op{

	private int index = 0;
	
	public int nextIndex() {
		return index++;
	}
	public void main(String[] args) {
		nextIndex();
	}
	
}