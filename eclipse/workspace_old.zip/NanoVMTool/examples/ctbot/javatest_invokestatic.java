

class JavaTest_invokestatic{
	static int addTwo(int a,int b) {
		return a+b;
	}
	public static void main(String[] args) {
		int i = addTwo(12,13);
	}
	
}