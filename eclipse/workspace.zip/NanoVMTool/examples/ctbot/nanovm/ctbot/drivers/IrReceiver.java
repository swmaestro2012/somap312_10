package nanovm.ctbot.drivers;

public class IrReceiver
{
  public static native int getCommand();
}

