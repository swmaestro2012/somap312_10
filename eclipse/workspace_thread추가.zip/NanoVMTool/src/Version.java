public class Version {
  public static String version = "V1.5";
}
