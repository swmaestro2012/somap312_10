/*
  AsuroLED.java

  testing asuros status led by cycling through all
  four possible states and pausing a second in between

  (c) 2005 Till Harbaum <till@harbaum.org>
*/

import nanovm.asuro.*;

class PrintlnTest{
	public static void main(String[] args) {
		int i = 100;
		int j = 200;
		System.out.println("Println test");
		System.out.println("Println test" + i);
		System.out.println("Println test" + j);
	}
}

     
