package nanovm.smbot.drivers;

public class SMThread
{	
	public native void start();
}


