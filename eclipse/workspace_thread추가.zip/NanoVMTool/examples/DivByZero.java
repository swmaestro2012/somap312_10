/*
  DivByZero.java
 */

class DivByZero {
  public static void main(String[] args) {
    System.out.println("Prepare for devision ...");
    System.out.println("10/0 is " + (10/0));
  }
}

     
