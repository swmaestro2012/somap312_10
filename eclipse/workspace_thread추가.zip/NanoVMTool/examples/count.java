/*
  count.java
 */

class count {
  public static void main(String[] args) {

    System.out.println("Counting from -10 to 10:");
    for(int i = -10; i <= 10; i++) {
      System.out.println("Counter: "+i);
    }

    System.out.println("Counting from 10 to -10:");
    for(int i = 10; i >= -10; i--) {
      System.out.println("Counter: "+i);
    }
  }
}

     
