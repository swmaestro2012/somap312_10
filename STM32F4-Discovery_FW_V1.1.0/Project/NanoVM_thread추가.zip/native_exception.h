#ifndef NATIVE_EXCEPTION_H
#define NATIVE_EXCEPTION_H

void native_exception_init(void);
void native_exception_invoke(u08_t mref);
#endif // NATIVE_EXCEPTION_H
