#ifndef NATIVE_THREAD_H
#define NATIVE_THREAD_H

void native_thread_init(u08_t mref);
void native_thread_invoke(u08_t mref);
#endif // NATIVE_EXCEPTION_H
